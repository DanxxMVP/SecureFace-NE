# cap2 > 2022-09-16 10:28am
https://universe.roboflow.com/ny/cap2

Provided by a Roboflow user
License: CC BY 4.0

